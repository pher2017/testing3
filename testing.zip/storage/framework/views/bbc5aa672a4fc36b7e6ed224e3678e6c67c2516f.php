<?php $__env->startSection('content'); ?>
    <p></p>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left my-3 mb-5">
                <h2>Fichas </h2>
            </div>

            <div class="col-lg-12 mb-4">

                    <form action="<?php echo e(route('fichas.index')); ?>" method="GET" class="form-inline">
                        <div class="row mb-2">
                            <div class="col-6">
                                <input type="text" class="form-control" name="search" placeholder="Buscar por Apellido"
                                    value="<?php echo e(request()->get('search')); ?>">
                            </div>
                            <div class="col-2">
                                <button type="submit" class="btn btn-primary">Buscar</button>
                            </div>
                            <div class="col-4">
                                <div class="d-flex flex-row-reverse">
                                    <div class="">
                                        <a class="btn btn-success" href="<?php echo e(route('fichas.create')); ?>"> Crear
                                            Ficha</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

            </div>
        </div>
    </div>


    <div class="table-responsive">
        <table class="table table-striped mt-2">
            <tr style="text-align: center">
                <th>No</th>
                <th>Rut</th>
                <th>Nombres</th>
                <th>Apellidos</th>
                <th>Direccion</th>
                <th>Ciudad</th>
                <th>Telefono</th>
                <th>Email</th>
                <th>Fecha Nacimiento</th>
                <th>Estado Civil</th>
                <th>Comentarios</th>
                <th width="200px">Action</th>
            </tr>
            <?php $__currentLoopData = $fichas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ficha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="text-nowrap">
                    <td><?php echo e($ficha->id); ?></td>
                    <td><?php echo e($ficha->rut); ?></td>
                    <td><?php echo e($ficha->nombres); ?></td>
                    <td><?php echo e($ficha->apellidos); ?></td>
                    <td><?php echo e($ficha->direccion); ?></td>
                    <td><?php echo e($ficha->ciudad); ?></td>
                    <td><?php echo e($ficha->telefono); ?></td>
                    <td><?php echo e($ficha->email); ?></td>
                    <td><?php echo e($ficha->fecha_nacimiento); ?></td>
                    <td><?php echo e($ficha->estado_civil); ?></td>
                    <td><?php echo e($ficha->comentarios); ?></td>
                    <td style="text-align:center">
                        <form action="<?php echo e(route('fichas.destroy', $ficha->id)); ?>" method="POST">

                            <a class="btn btn-info" href="<?php echo e(route('fichas.show', $ficha->id)); ?>"><i
                                    class="fa-sharp fa-solid fa-eye"></i></a>

                            <a class="btn btn-primary" href="<?php echo e(route('fichas.edit', $ficha->id)); ?>"><i
                                    class="fa-solid fa-pen-to-square"></i></a>

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fichas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\testing\resources\views/fichas/index.blade.php ENDPATH**/ ?>