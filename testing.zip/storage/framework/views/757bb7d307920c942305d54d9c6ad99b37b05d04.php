<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Ver Ficha</h2>
            </div>
            <div class="d-flex flex-row-reverse">
                <a class="btn btn-primary" href="<?php echo e(route('fichas.index')); ?>"> Volver</a>
            </div>
        </div>
    </div>
    <div class="card-body">
         <form action="<?php echo e(route('fichas.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Rut:</strong>
                        <?php echo e($ficha->rut); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Nombres:</strong>
                    <?php echo e($ficha->nombres); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Apellidos:</strong>
                    <?php echo e($ficha->apellidos); ?>

                </div>
            </div>
            <div class="col-xs-12 col-md-12">
                <div class="form-group">
                    <strong>Direccion:</strong>
                    <?php echo e($ficha->direccion); ?>

                </div>
            </div>
            <div class="col-xs-12 col-md-12">
                <div class="form-group">
                    <strong>Ciudad:</strong>
                    <?php echo e($ficha->ciudad); ?>

                </div>
            </div>
            <div class="col-xs-12 col-md-12">
                <div class="form-group">
                    <strong>Telefono:</strong>
                    <?php echo e($ficha->telefono); ?>

                </div>
            </div>
            <div class="col-xs-12 col-md-12">
                <div class="form-group">
                    <strong>Email:</strong>
                    <?php echo e($ficha->email); ?>

                </div>
            </div>
            <div class="col-xs-12 col-md-12">
                <div class="form-group">
                    <strong>Fecha de Nacimiento:</strong>
                    <?php echo e($ficha->fecha_nacimiento); ?>

                </div>
            </div>
            <div class="col-xs-12 col-md-12">
                <div class="form-group">
                    <strong>Estado Civil</strong>
                    <?php echo e($ficha->estado_civil); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comentarios:</strong>
                    <?php echo e($ficha->comentarios); ?>

                </div>
            </div>

    </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('fichas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\testing\resources\views/fichas/show.blade.php ENDPATH**/ ?>